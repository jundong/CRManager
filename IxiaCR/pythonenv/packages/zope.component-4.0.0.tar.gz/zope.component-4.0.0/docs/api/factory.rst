Factory APIs
============

.. autofunction:: zope.component.createObject

.. autofunction:: zope.component.getFactoryInterfaces

.. autofunction:: zope.component.getFactoriesFor

