:mod:`zope.component`
=====================

Contents:

.. toctree::
   :maxdepth: 2

   narr
   socketexample
   event
   factory
   persistentregistry
   zcml
   configure
   hooks
   testlayer

   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
