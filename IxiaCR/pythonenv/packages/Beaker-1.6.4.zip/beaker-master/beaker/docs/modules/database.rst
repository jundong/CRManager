:mod:`beaker.ext.database` -- Database Container and NameSpace Manager classes 
==============================================================================

.. automodule:: beaker.ext.database

Module Contents
---------------

.. autoclass:: DatabaseContainer
.. autoclass:: DatabaseNamespaceManager
