`Jinja2 <http:http://jinja.pocoo.org>`_ bindings for Pyramid
============================================================

These are bindings for the `Jinja2 templating system
<http:http://jinja.pocoo.org>`_ for the `Pyramid
<http://docs.pylonshq.com/>`_ web framework.

See http://docs.pylonsproject.org/projects/pyramid_jinja2/dev/
for documentation or ``index.rst`` in the ``docs`` sub
directory of the source distribution.
