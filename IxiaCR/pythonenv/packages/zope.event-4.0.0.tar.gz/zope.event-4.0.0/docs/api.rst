:mod:`zope.event` API Reference
===============================

The package exports the following API symbols.

Data
----

.. autodata:: zope.event.subscribers


Functions
---------
   
.. autofunction:: zope.event.notify
