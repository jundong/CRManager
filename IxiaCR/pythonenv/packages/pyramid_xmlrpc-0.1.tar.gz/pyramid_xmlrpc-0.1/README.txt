pyramid_xmlrpc README
=====================

Please see docs/index.rst for the documentation.
