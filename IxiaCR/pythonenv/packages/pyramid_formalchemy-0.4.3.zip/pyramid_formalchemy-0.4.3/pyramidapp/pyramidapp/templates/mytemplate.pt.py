registry = dict(version=0)
def bind():
    from cPickle import loads as _loads
    _lookup_attr = _loads('cchameleon.core.codegen\nlookup_attr\np1\n.')
    _attrs_4360318608 = _loads('(dp1\nVid\np2\nVfooter\np3\ns.')
    _attrs_4360315152 = _loads('(dp1\nVhref\np2\nVhttp://docs.pylonshq.com/pyramid/dev/#tutorials\np3\ns.')
    _re_amp = _loads("cre\n_compile\np1\n(S'&(?!([A-Za-z]+|#[0-9]+);)'\np2\nI0\ntRp3\n.")
    _attrs_4360318480 = _loads('(dp1\nVid\np2\nVwrap\np3\ns.')
    _attrs_4360315536 = _loads('(dp1\nVhref\np2\nVhttp://docs.pylonshq.com/pyramid/dev/#sample-applications\np3\ns.')
    _attrs_4360315728 = _loads('(dp1\nVclass\np2\nVmiddle align-center\np3\ns.')
    _attrs_4360317456 = _loads('(dp1\nVcontent\np2\nVpython web application\np3\nsVname\np4\nVkeywords\np5\ns.')
    _attrs_4360318864 = _loads('(dp1\nVid\np2\nVbottom\np3\ns.')
    _attrs_4360315216 = _loads('(dp1\nVclass\np2\nVtop align-center\np3\ns.')
    _attrs_4360315600 = _loads("(dp1\nVsrc\np2\nV${request.static_url('pyramidapp:static/pyramid.png')}\np3\nsVheight\np4\nV169\np5\nsVwidth\np6\nV750\np7\nsValt\np8\nVpyramid\np9\ns.")
    _attrs_4360316624 = _loads('(dp1\nVclass\np2\nVfooter\np3\ns.')
    _attrs_4360315792 = _loads('(dp1\n.')
    _attrs_4360297616 = _loads('(dp1\nVxmlns\np2\nVhttp://www.w3.org/1999/xhtml\np3\nsVxml:lang\np4\nVen\np5\ns.')
    _attrs_4360316368 = _loads('(dp1\n.')
    _attrs_4360341136 = _loads('(dp1\nVid\np2\nVmiddle\np3\ns.')
    _attrs_4360315024 = _loads('(dp1\nVhref\np2\nVhttp://docs.pylonshq.com/pyramid/dev/#api-documentation\np3\ns.')
    _attrs_4360318288 = _loads('(dp1\n.')
    _attrs_4360316880 = _loads('(dp1\n.')
    _attrs_4360316944 = _loads('(dp1\n.')
    _attrs_4360315280 = _loads('(dp1\n.')
    _init_default = _loads('cchameleon.core.generation\ninitialize_default\np1\n.')
    _attrs_4360317584 = _loads('(dp1\nVcontent\np2\nVpyramid web application\np3\nsVname\np4\nVdescription\np5\ns.')
    _attrs_4360318544 = _loads('(dp1\nVhref\np2\nVhttp://pylonshq.com\np3\ns.')
    _attrs_4360314960 = _loads('(dp1\n.')
    _init_tal = _loads('cchameleon.core.generation\ninitialize_tal\np1\n.')
    _attrs_4360318096 = _loads('(dp1\nVmedia\np2\nVscreen\np3\nsVcharset\np4\nVutf-8\np5\nsVhref\np6\nVhttp://fonts.googleapis.com/css?family=Nobile:regular,italic,bold,bolditalic&subset=latin\np7\nsVrel\np8\nVstylesheet\np9\nsVtype\np10\nVtext/css\np11\ns.')
    _attrs_4360317904 = _loads('(dp1\n.')
    _attrs_4360316816 = _loads('(dp1\nVid\np2\nVright\np3\nsVclass\np4\nValign-left\np5\ns.')
    _attrs_4360316752 = _loads('(dp1\nVid\np2\nVleft\np3\nsVclass\np4\nValign-right\np5\ns.')
    _attrs_4360315088 = _loads('(dp1\n.')
    _attrs_4360315408 = _loads('(dp1\nVhref\np2\nVhttp://docs.pylonshq.com/pyramid/dev/#change-history\np3\ns.')
    _attrs_4360318032 = _loads('(dp1\nVclass\np2\nVlinks\np3\ns.')
    _attrs_4360315472 = _loads('(dp1\n.')
    _attrs_4360318672 = _loads('(dp1\n.')
    _attrs_4360315344 = _loads('(dp1\n.')
    _attrs_4360316304 = _loads('(dp1\nVclass\np2\nVapp-name\np3\ns.')
    _attrs_4360317136 = _loads('(dp1\nVcontent\np2\nVtext/html;charset=UTF-8\np3\nsVhttp-equiv\np4\nVContent-Type\np5\ns.')
    _init_stream = _loads('cchameleon.core.generation\ninitialize_stream\np1\n.')
    _attrs_4360315984 = _loads('(dp1\nVclass\np2\nVbottom\np3\ns.')
    _init_scope = _loads('cchameleon.core.utils\necontext\np1\n.')
    _attrs_4360318800 = _loads('(dp1\nVhref\np2\nVhttp://docs.pylonshq.com/pyramid/dev/#narrative-documentation\np3\ns.')
    _attrs_4360317776 = _loads('(dp1\nVtype\np2\nVsubmit\np3\nsVid\np4\nVx\nsVvalue\np5\nVGo\np6\ns.')
    _attrs_4360317648 = _loads('(dp1\nVname\np2\nVq\nsVvalue\np3\nV\nsVtype\np4\nVtext\np5\nsVid\np6\nVq\ns.')
    _attrs_4360317392 = _loads('(dp1\nVaction\np2\nVhttp://docs.pylonshq.com/pyramid/dev/search.html\np3\nsVmethod\np4\nVget\np5\ns.')
    _attrs_4360315856 = _loads('(dp1\nVhref\np2\nVhttp://docs.pylonshq.com/pyramid/dev/#support-and-development\np3\ns.')
    _attrs_4360316112 = _loads('(dp1\nVhref\np2\nVirc://irc.freenode.net#pyramid\np3\ns.')
    _attrs_4360318416 = _loads('(dp1\n.')
    _attrs_4360317968 = _loads('(dp1\nVmedia\np2\nVscreen\np3\nsVcharset\np4\nVutf-8\np5\nsVhref\np6\nVhttp://fonts.googleapis.com/css?family=Neuton&subset=latin\np7\nsVrel\np8\nVstylesheet\np9\nsVtype\np10\nVtext/css\np11\ns.')
    _attrs_4360317712 = _loads("(dp1\nVhref\np2\nV${request.static_url('pyramidapp:static/favicon.ico')}\np3\nsVrel\np4\nVshortcut icon\np5\ns.")
    _attrs_4360318736 = _loads('(dp1\nVid\np2\nVtop\np3\ns.')
    _attrs_4360315920 = _loads('(dp1\nVclass\np2\nVapp-welcome\np3\ns.')
    _attrs_4360317328 = _loads('(dp1\n.')
    _attrs_4360317840 = _loads("(dp1\nVmedia\np2\nVscreen\np3\nsVcharset\np4\nVutf-8\np5\nsVhref\np6\nV${request.static_url('pyramidapp:static/pylons.css')}\np7\nsVrel\np8\nVstylesheet\np9\nsVtype\np10\nVtext/css\np11\ns.")
    _attrs_4360297360 = _loads('(dp1\n.')
    def render(econtext, rcontext=None):
        macros = econtext.get('macros')
        _translate = econtext.get('_translate')
        _slots = econtext.get('_slots')
        target_language = econtext.get('target_language')
        u'_init_stream()'
        (_out, _write, ) = _init_stream()
        u'_init_tal()'
        (_attributes, repeat, ) = _init_tal()
        u'_init_default()'
        _default = _init_default()
        u'None'
        default = None
        u'None'
        _domain = None
        _write('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n')
        attrs = _attrs_4360297616
        _write(u'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">\n')
        attrs = _attrs_4360297360
        _write(u'<head>\n\t')
        attrs = _attrs_4360316880
        _write(u'<title>The Pyramid Web Application Development Framework</title>\n\t')
        attrs = _attrs_4360317136
        _write(u'<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />\n\t')
        attrs = _attrs_4360317456
        _write(u'<meta name="keywords" content="python web application" />\n\t')
        attrs = _attrs_4360317584
        _write(u'<meta name="description" content="pyramid web application" />\n\t')
        attrs = _attrs_4360317712
        'join(value("request.static_url(\'pyramidapp:static/favicon.ico\')"),)'
        _write(u'<link rel="shortcut icon"')
        _tmp1 = _lookup_attr(econtext['request'], 'static_url')('pyramidapp:static/favicon.ico')
        if (_tmp1 is _default):
            _tmp1 = u"${request.static_url('pyramidapp:static/favicon.ico')}"
        if ((_tmp1 is not None) and (_tmp1 is not False)):
            if (_tmp1.__class__ not in (str, unicode, int, float, )):
                _tmp1 = unicode(_translate(_tmp1, domain=_domain, mapping=None, target_language=target_language, default=None))
            else:
                if not isinstance(_tmp1, unicode):
                    _tmp1 = str(_tmp1)
            if ('&' in _tmp1):
                if (';' in _tmp1):
                    _tmp1 = _re_amp.sub('&amp;', _tmp1)
                else:
                    _tmp1 = _tmp1.replace('&', '&amp;')
            if ('<' in _tmp1):
                _tmp1 = _tmp1.replace('<', '&lt;')
            if ('>' in _tmp1):
                _tmp1 = _tmp1.replace('>', '&gt;')
            if ('"' in _tmp1):
                _tmp1 = _tmp1.replace('"', '&quot;')
            _write(((' href="' + _tmp1) + '"'))
        _write(u' />\n\t')
        attrs = _attrs_4360317840
        'join(value("request.static_url(\'pyramidapp:static/pylons.css\')"),)'
        _write(u'<link rel="stylesheet"')
        _tmp1 = _lookup_attr(econtext['request'], 'static_url')('pyramidapp:static/pylons.css')
        if (_tmp1 is _default):
            _tmp1 = u"${request.static_url('pyramidapp:static/pylons.css')}"
        if ((_tmp1 is not None) and (_tmp1 is not False)):
            if (_tmp1.__class__ not in (str, unicode, int, float, )):
                _tmp1 = unicode(_translate(_tmp1, domain=_domain, mapping=None, target_language=target_language, default=None))
            else:
                if not isinstance(_tmp1, unicode):
                    _tmp1 = str(_tmp1)
            if ('&' in _tmp1):
                if (';' in _tmp1):
                    _tmp1 = _re_amp.sub('&amp;', _tmp1)
                else:
                    _tmp1 = _tmp1.replace('&', '&amp;')
            if ('<' in _tmp1):
                _tmp1 = _tmp1.replace('<', '&lt;')
            if ('>' in _tmp1):
                _tmp1 = _tmp1.replace('>', '&gt;')
            if ('"' in _tmp1):
                _tmp1 = _tmp1.replace('"', '&quot;')
            _write(((' href="' + _tmp1) + '"'))
        _write(u' type="text/css" media="screen" charset="utf-8" />\n\t')
        attrs = _attrs_4360317968
        _write(u'<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Neuton&amp;subset=latin" type="text/css" media="screen" charset="utf-8" />\n\t')
        attrs = _attrs_4360318096
        u"request.static_url('pyramidapp:static/ie6.css')"
        _write(u'<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Nobile:regular,italic,bold,bolditalic&amp;subset=latin" type="text/css" media="screen" charset="utf-8" />\n\t<!--[if lte IE 6]>\n\t<link rel="stylesheet" href="')
        _tmp1 = _lookup_attr(econtext['request'], 'static_url')('pyramidapp:static/ie6.css')
        _tmp = _tmp1
        if (_tmp.__class__ not in (str, unicode, int, float, )):
            try:
                _tmp = _tmp.__html__
            except:
                _tmp = _translate(_tmp, domain=_domain, mapping=None, target_language=target_language, default=None)
            else:
                _tmp = _tmp()
                _write(_tmp)
                _tmp = None
        if (_tmp is not None):
            if not isinstance(_tmp, unicode):
                _tmp = str(_tmp)
            if ('&' in _tmp):
                if (';' in _tmp):
                    _tmp = _re_amp.sub('&amp;', _tmp)
                else:
                    _tmp = _tmp.replace('&', '&amp;')
            if ('<' in _tmp):
                _tmp = _tmp.replace('<', '&lt;')
            if ('>' in _tmp):
                _tmp = _tmp.replace('>', '&gt;')
            _write(_tmp)
        _write(u'" type="text/css" media="screen" charset="utf-8" />\n\t<![endif]-->\n</head>\n')
        attrs = _attrs_4360316944
        _write(u'<body>\n\t')
        attrs = _attrs_4360318480
        _write(u'<div id="wrap">\n\t\t')
        attrs = _attrs_4360318736
        _write(u'<div id="top">\n\t\t\t')
        attrs = _attrs_4360315216
        _write(u'<div class="top align-center">\n\t\t\t\t')
        attrs = _attrs_4360315280
        _write(u'<div>')
        attrs = _attrs_4360315600
        'join(value("request.static_url(\'pyramidapp:static/pyramid.png\')"),)'
        _write(u'<img')
        _tmp1 = _lookup_attr(econtext['request'], 'static_url')('pyramidapp:static/pyramid.png')
        if (_tmp1 is _default):
            _tmp1 = u"${request.static_url('pyramidapp:static/pyramid.png')}"
        if ((_tmp1 is not None) and (_tmp1 is not False)):
            if (_tmp1.__class__ not in (str, unicode, int, float, )):
                _tmp1 = unicode(_translate(_tmp1, domain=_domain, mapping=None, target_language=target_language, default=None))
            else:
                if not isinstance(_tmp1, unicode):
                    _tmp1 = str(_tmp1)
            if ('&' in _tmp1):
                if (';' in _tmp1):
                    _tmp1 = _re_amp.sub('&amp;', _tmp1)
                else:
                    _tmp1 = _tmp1.replace('&', '&amp;')
            if ('<' in _tmp1):
                _tmp1 = _tmp1.replace('<', '&lt;')
            if ('>' in _tmp1):
                _tmp1 = _tmp1.replace('>', '&gt;')
            if ('"' in _tmp1):
                _tmp1 = _tmp1.replace('"', '&quot;')
            _write(((' src="' + _tmp1) + '"'))
        _write(u' width="750" height="169" alt="pyramid" /></div>\n\t\t\t</div>\n\t\t</div>\n\t\t')
        attrs = _attrs_4360341136
        _write(u'<div id="middle">\n\t\t\t')
        attrs = _attrs_4360315728
        _write(u'<div class="middle align-center">\n\t\t\t\t')
        attrs = _attrs_4360315920
        _write(u'<p class="app-welcome">\n\t\t\t\t\tWelcome to ')
        attrs = _attrs_4360316304
        u'project'
        _write(u'<span class="app-name">')
        _tmp1 = econtext['project']
        _tmp = _tmp1
        if (_tmp.__class__ not in (str, unicode, int, float, )):
            try:
                _tmp = _tmp.__html__
            except:
                _tmp = _translate(_tmp, domain=_domain, mapping=None, target_language=target_language, default=None)
            else:
                _tmp = _tmp()
                _write(_tmp)
                _tmp = None
        if (_tmp is not None):
            if not isinstance(_tmp, unicode):
                _tmp = str(_tmp)
            if ('&' in _tmp):
                if (';' in _tmp):
                    _tmp = _re_amp.sub('&amp;', _tmp)
                else:
                    _tmp = _tmp.replace('&', '&amp;')
            if ('<' in _tmp):
                _tmp = _tmp.replace('<', '&lt;')
            if ('>' in _tmp):
                _tmp = _tmp.replace('>', '&gt;')
            _write(_tmp)
        _write(u'</span>, an application generated by')
        attrs = _attrs_4360316368
        _write(u'<br />\n\t\t\t\t\tthe Pyramid web application development framework.\n\t\t\t\t</p>\n\t\t\t</div>\n\t\t</div>\n\t\t')
        attrs = _attrs_4360318864
        _write(u'<div id="bottom">\n\t\t\t')
        attrs = _attrs_4360315984
        _write(u'<div class="bottom">\n\t\t\t\t')
        attrs = _attrs_4360316752
        _write(u'<div id="left" class="align-right">\n\t\t\t\t\t')
        attrs = _attrs_4360317328
        _write(u'<h2>Search documentation</h2>\n\t\t\t\t\t')
        attrs = _attrs_4360317392
        _write(u'<form method="get" action="http://docs.pylonshq.com/pyramid/dev/search.html">\n\t\t      \t\t\t')
        attrs = _attrs_4360317648
        _write(u'<input type="text" id="q" name="q" value="" />\n\t\t      \t\t\t')
        attrs = _attrs_4360317776
        _write(u'<input type="submit" id="x" value="Go" />\n\t\t  \t\t\t</form>\n\t\t\t\t</div>\n\t\t\t\t')
        attrs = _attrs_4360316816
        _write(u'<div id="right" class="align-left">\n\t\t\t\t\t')
        attrs = _attrs_4360317904
        _write(u'<h2>Pyramid links</h2>\n\t\t\t\t\t')
        attrs = _attrs_4360318032
        _write(u'<ul class="links">\n\t\t\t\t\t\t')
        attrs = _attrs_4360318288
        _write(u'<li>\n\t\t\t\t\t\t\t')
        attrs = _attrs_4360318544
        _write(u'<a href="http://pylonshq.com">Pylons Website</a>\n\t\t\t\t\t\t</li>\n\t\t\t\t\t\t')
        attrs = _attrs_4360318416
        _write(u'<li>\n\t\t\t\t\t\t\t')
        attrs = _attrs_4360318800
        _write(u'<a href="http://docs.pylonshq.com/pyramid/dev/#narrative-documentation">Narrative Documentation</a>\n\t\t\t\t\t\t</li>\n\t\t\t\t\t\t')
        attrs = _attrs_4360318672
        _write(u'<li>\n\t\t\t\t\t\t\t')
        attrs = _attrs_4360315024
        _write(u'<a href="http://docs.pylonshq.com/pyramid/dev/#api-documentation">API Documentation</a>\n\t\t\t\t\t\t</li>\n\t\t\t\t\t\t')
        attrs = _attrs_4360314960
        _write(u'<li>\n\t\t\t\t\t\t\t')
        attrs = _attrs_4360315152
        _write(u'<a href="http://docs.pylonshq.com/pyramid/dev/#tutorials">Tutorials</a>\n\t\t\t\t\t\t</li>\n\t\t\t\t\t\t')
        attrs = _attrs_4360315088
        _write(u'<li>\n\t\t\t\t\t\t\t')
        attrs = _attrs_4360315408
        _write(u'<a href="http://docs.pylonshq.com/pyramid/dev/#change-history">Change History</a>\n\t\t\t\t\t\t</li>\n\t\t\t\t\t\t')
        attrs = _attrs_4360315344
        _write(u'<li>\n\t\t\t\t\t\t\t')
        attrs = _attrs_4360315536
        _write(u'<a href="http://docs.pylonshq.com/pyramid/dev/#sample-applications">Sample Applications</a>\n\t\t\t\t\t\t</li>\n\t\t\t\t\t\t')
        attrs = _attrs_4360315472
        _write(u'<li>\n\t\t\t\t\t\t\t')
        attrs = _attrs_4360315856
        _write(u'<a href="http://docs.pylonshq.com/pyramid/dev/#support-and-development">Support and Development</a>\n\t\t\t\t\t\t</li>\n\t\t\t\t\t\t')
        attrs = _attrs_4360315792
        _write(u'<li>\n\t\t\t\t\t\t\t')
        attrs = _attrs_4360316112
        _write(u'<a href="irc://irc.freenode.net#pyramid">IRC Channel</a>\n\t\t\t\t\t\t</li>\n\t\t  \t\t\t</ul>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n\t')
        attrs = _attrs_4360318608
        _write(u'<div id="footer">\n\t\t')
        attrs = _attrs_4360316624
        _write(u'<div class="footer">\xa9 Copyright 2008-2011, Agendaless Consulting.</div>\n\t</div>\n</body>\n</html>')
        return _out.getvalue()
    return render

__filename__ = '/Users/gawel/py/formalchemy_project/pyramid_formalchemy/pyramidapp/pyramidapp/templates/mytemplate.pt'
registry[(None, True, '1488bdb950901f8f258549439ef6661a49aae984')] = bind()
