pyramidapp README



