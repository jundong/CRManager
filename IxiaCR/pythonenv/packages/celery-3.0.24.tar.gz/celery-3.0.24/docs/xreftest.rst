xreftest
========

Must not be in public docs
--------------------------

hello, how do you do3


``meth @Task.retry``: :meth:`@Task.retry`

``meth @-Task.retry``: :meth:`@-Task.retry`

``meth ~@Task.retry``: :meth:`~@Task.retry`


``class @Celery``: :class:`@Celery`

``class @-Celery``: :class:`@-Celery`

``class ~@Celery``: :class:`~@Celery`


``meth @Celery.config_from_object``: :meth:`@Celery.config_from_object`

``meth @-Celery.config_from_object``: :meth:`@-Celery.config_from_object`

``meth ~@Celery.config_from_object``: :meth:`~@Celery.config_from_object`

``meth celery.Celery.config_from_object``: :meth:`@Celery.send_task`

:class:`celery.Celery`

:class:`celery.subtask.link`


``attr @amqp``:   :attr:`@amqp`

``attr @-amqp``:   :attr:`@-amqp`

``attr ~@amqp``:   :attr:`~@amqp`


``meth @amqp.TaskConsumer``:  :meth:`@amqp.TaskConsumer`

``meth @-amqp.TaskConsumer``: :meth:`@-amqp.TaskConsumer`

``meth ~@amqp.TaskConsumer``: :meth:`~@amqp.TaskConsumer`


``exc @NotRegistered``: :exc:`@NotRegistered`

``exc @-NotRegistered``: :exc:`@-NotRegistered`
