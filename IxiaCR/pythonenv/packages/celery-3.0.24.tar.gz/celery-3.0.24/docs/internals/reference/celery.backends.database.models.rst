======================================
 celery.backends.database.models
======================================

.. contents::
    :local:
.. currentmodule:: celery.backends.database.models

.. automodule:: celery.backends.database.models
    :members:
    :undoc-members:
