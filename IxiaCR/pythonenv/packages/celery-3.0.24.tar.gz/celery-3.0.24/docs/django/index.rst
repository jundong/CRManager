.. _django:

=========
 Django
=========

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 2

    first-steps-with-django
    unit-testing

