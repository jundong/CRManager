class Root(object):
    def __init__(self, request):
        self.request = request
