.. _settings_module:

:mod:`pyramid.settings`
--------------------------

.. automodule:: pyramid.settings

  .. autofunction:: get_settings

  .. autofunction:: asbool

  .. autofunction:: aslist


