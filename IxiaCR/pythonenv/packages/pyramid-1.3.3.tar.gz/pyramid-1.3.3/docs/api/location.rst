.. _location_module:

:mod:`pyramid.location`
--------------------------

.. automodule:: pyramid.location

  .. autofunction:: lineage

  .. autofunction:: inside


