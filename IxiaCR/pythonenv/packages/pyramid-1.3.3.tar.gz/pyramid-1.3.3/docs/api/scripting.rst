.. _scripting_module:

:mod:`pyramid.scripting`
---------------------------

.. automodule:: pyramid.scripting

  .. autofunction:: get_root

  .. autofunction:: prepare

