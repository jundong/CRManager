:app:`Pyramid` Change History
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. include:: ../CHANGES.txt

.. include:: ../HISTORY.txt

:mod:`repoze.bfg` Change History (previous name for Pyramid)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. include:: ../BFG_HISTORY.txt
