from fanstatic import Library, Resource

foo = Library('foo', 'resources')

style = Resource(foo, 'style.css')
