pyramid_beaker
==============

Provides a session factory for the `Pyramid <http://docs.pylonsproject.org>`_
web framework backed by the `Beaker <http://beaker.groovie.org/>`_ sessioning
system.

See `the Pylons Project documentation <http://docs.pylonsproject.org>`_ for
more information.
